#ifndef _FEAR
#define _FEAR

void fear(void);
	
#endif
