#ifndef _PUSH
#define _PUSH

void push();
void listen();
void _listen(void (*foo)());
void _pushObject();
	
#endif
