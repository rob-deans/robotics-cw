#ifndef _WALLFOLLOW
#define _WALLFOLLOW


void run_wallfollow();

#endif
