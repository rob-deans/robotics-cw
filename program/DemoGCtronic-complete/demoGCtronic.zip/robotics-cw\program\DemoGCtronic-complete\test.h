#ifndef TEST
#define TEST
void test();
#endif