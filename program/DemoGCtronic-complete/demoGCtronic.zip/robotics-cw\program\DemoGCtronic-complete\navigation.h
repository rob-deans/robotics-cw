#ifndef _NAVIGATION
#define _NAVIGATION

void navigateWall(void);
int checkLeft();
void followLeft();

#endif
