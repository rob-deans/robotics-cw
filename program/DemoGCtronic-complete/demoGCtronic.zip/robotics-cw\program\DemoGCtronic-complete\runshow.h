#ifndef _SHOW
#define _SHOW


void run_SensDispl();
void run_CameraTurn();
void run_DustCleaner();

#endif
