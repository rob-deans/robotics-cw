#ifndef _CURIOUS
#define _CURIOUS

void curious(void);

void spin(void);

#endif
