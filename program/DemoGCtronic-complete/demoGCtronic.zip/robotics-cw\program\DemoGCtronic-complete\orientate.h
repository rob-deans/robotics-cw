#ifndef _ORIENTATE
#define _ORIENTATE


void wallfollow();

#endif
