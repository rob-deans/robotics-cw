#ifndef _LOVE
#define _LOVE

void love(void);
	
#endif
