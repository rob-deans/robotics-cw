
int run_accelerometer();
