#include "p30F6014A.h"
#include "stdio.h"
#include "string.h"
#include <motor_led/e_epuck_ports.h>
#include <motor_led/e_init_port.h>
#include <motor_led/e_led.h>
#include <motor_led/e_motors.h>
#include <utility/utility.h>
#include <uart/e_uart_char.h>
#include <a_d/advance_ad_scan/e_ad_conv.h>
#include <a_d/advance_ad_scan/e_prox.h>

#include "helpers.h"
#include "navigation.h"

// Navigates around a wall until it sees something
void navigateWall() {

	while(checkLeft()) {
		followLeft();
	}
}

// may need to change this in the end
int checkLeft() {
	return inProximity(close, left);
}

// Make a 90 degree turn
void nturnLeft() {
	int initSteps = e_get_steps_right();

	e_set_speed_left(-500);
	e_set_speed_right(500);

	while(e_get_steps_right() < initSteps + (FULL_SPIN_STEPS / 4) - 10);

	stop();
}

// Follows the wall on the left until it sees something in the front
void followLeft() {
	nforward(medium);
	while(1) {
		if(inProximity(dmedium, front)) {
			e_set_led(0, 1);
			nturnLeft();
			break;
		}

		if(!checkLeft()) {
			e_set_led(6, 0);
			e_set_led(2, 1);
			moveDistance(h_length, medium);
			nturnLeft();
			nforward(medium);
			while(!checkLeft());
			stop();
			break;
		}
	}
}
