#ifndef _AGGRESSIVE
#define _AGGRESSIVE

void aggressive(void);
	
#endif
