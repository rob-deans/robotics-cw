#ifndef _FOLLOWYELLOW
#define _FOLLOWYELLOW

void followYellow(void);
	
#endif
