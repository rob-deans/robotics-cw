#ifndef _FOLLOWGREEN
#define _FOLLOWGREEN

void followGreen(void);
	
#endif
