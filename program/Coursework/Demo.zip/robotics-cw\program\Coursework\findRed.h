#ifndef _FINDRED
#define _FINDRED

void findRed(void);
	
#endif
