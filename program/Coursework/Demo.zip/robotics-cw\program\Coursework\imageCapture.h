#ifndef _FOLLOWER
#define _FOLLOWER

void imageCapture(void);
	
#endif
